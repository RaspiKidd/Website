* [93c4ea5](https://github.com/TryGhost/Casper/commit/93c4ea5) 2.9.11 - Fabien O'Carroll
* [87abdc2](https://github.com/TryGhost/Casper/commit/87abdc2) Updated travis.yml file - Hannah Wolfe
* [50c53f4](https://github.com/TryGhost/Casper/commit/50c53f4) Updated .travis.yml file - Hannah Wolfe
* [dc05ff2](https://github.com/TryGhost/Casper/commit/dc05ff2) Update Renovate Configuration - Hannah Wolfe
